import{l as o,a as r}from"../chunks/Vbzt7Iy5.js";export{o as load_css,r as start};
